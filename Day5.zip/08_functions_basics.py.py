def order(item):
    print(f"Order placed: your order is: {item}")
    
#eggs=>4
#tot=(base_price +5)*1.15

def calculate_total(item):
    base_price=25
    VAT=0.15
    totalPrice=(base_price+len(item))*1.15
    return totalPrice

def get_order():
    print("Preparing order")
    return'Order Ready'

myFood=input("What would you like? ")
order(myFood)

print(get_order())# only use whn it has a return statement
order_total=calculate_total(myFood)
print(f" Your order costs: R{round(order_total,2)}")